/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Individuos;

import javax.swing.JOptionPane;

/**
 *
 * @author USUARIO
 */
public class Usuario extends Persona{
    private String clave;

    public Usuario( String nombre, long Id,String clave) {
        super(nombre, Id);
        this.clave = clave;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    @Override
    public void validacion(String nombreus, String claveus) {
       if (nombre.equals(nombreus)){
           if(clave.equals(claveus)){
               JOptionPane.showMessageDialog(null, "Bienvenido al sistema");
           }else{
           JOptionPane.showMessageDialog(null, "La contraseña es invalida","Error",JOptionPane.ERROR);
           }           
       }else {
       JOptionPane.showMessageDialog(null, "El usuario es invalido","Error",JOptionPane.ERROR);
       }
    }



   
    



}
