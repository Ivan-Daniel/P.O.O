/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.tienda;

import Articulos.*;
import Individuos.*;

import javax.swing.JOptionPane;

/**
 *
 * @author SALA
 */
public class Tienda extends Cliente{
    private int cantidad_botas;
    private int cantidad_camisas;
    private int cantidad_tenis;
    private int cantidad_jeans;
    private Botas utbotas;
    private Camisas utcamisas;
    private Jeans utjeans;
    private Tenis uttenis;
//Constructor 1
    public Tienda(int cantidad_botas, int cantidad_camisas, int cantidad_tenis, int cantidad_jeans, Botas utbotas, Camisas utcamisas, Jeans utjeans, Tenis uttenis, String nombre, long Id) {
        super(nombre, Id);
        this.cantidad_botas = cantidad_botas;
        this.cantidad_camisas = cantidad_camisas;
        this.cantidad_tenis = cantidad_tenis;
        this.cantidad_jeans = cantidad_jeans;
        this.utbotas = utbotas;
        this.utcamisas = utcamisas;
        this.utjeans = utjeans;
        this.uttenis = uttenis;
    }
  //Constructor 2
    public Tienda(Botas utbotas, Camisas utcamisas, Jeans utjeans, Tenis uttenis, String nombre, long Id) {
        super(nombre, Id);
        this.utbotas = utbotas;
        this.utcamisas = utcamisas;
        this.utjeans = utjeans;
        this.uttenis = uttenis;
    }

  
    public void factura_camisa(){
    double x=0;
    x=uttenis.getPrecio()*cantidad_camisas;
    JOptionPane.showMessageDialog(null, "Señor "+nombre+" lo que tiene que pagar es: "+x+" camisas marca "+utcamisas.getMarca()+" y la cantidad son "+cantidad_camisas);
    }
    public void factura_tenis(){
    double t=0;
    t=uttenis.getPrecio()*cantidad_tenis;
    JOptionPane.showMessageDialog(null, "Señor "+nombre+" lo que pagar es: "+t+" tenis marca "+uttenis.getMarca()+" y la cantidad a llevar es "+cantidad_tenis);
    }
    public void factura_jeans(){
    double p=0;
    p=utjeans.getPrecio()*cantidad_jeans;
    JOptionPane.showMessageDialog(null, "Señor "+nombre+" lo que pagar es: "+p+" jeans de marca "+utjeans.getMarca()+" y la cantidad a llevar es "+cantidad_jeans);
    }
    public void factura_botas(){
    double r=0;
    r=utbotas.getPrecio()*cantidad_botas;
    JOptionPane.showMessageDialog(null, "Señor "+nombre+" lo que pagar es: "+r+"botas de marca "+utbotas.getMarca()+" y la cantidad a llevar es "+cantidad_botas);
    }
     public void Carta (){
        JOptionPane.showMessageDialog(null,"Tenemos camisas Charvet valoradas en 80.000$, Turnbull & Asser valoradas en 150.000$, vAlexander Kabbaz valoradas en 200.000$ "+"\n"+"Tenemos botas Pikolinos valoradas en 300.000$, Coronel Tapioca valoradas en 100.000$, Camper valoradas en 700.000$"+"\n"+"Tenemos Jeans LEE valorados en 60.000$, WRANGLER valorados en 120.000$, OGGI valorados en  130.00'$"+"\n"+"Tenemos Tenis Nike valorados en 115.000$, Converse valorados en 147.800$,Oliver Cabell valorados en 193.000$");
        }


    public Botas getUtbotas() {
        return utbotas;
    }

    public Camisas getUtcamisas() {
        return utcamisas;
    }

    public Jeans getUtjeans() {
        return utjeans;
    }

    public Tenis getUttenis() {
        return uttenis;
    }

    public void setUtbotas(Botas utbotas) {
        this.utbotas = utbotas;
    }

    public void setUtcamisas(Camisas utcamisas) {
        this.utcamisas = utcamisas;
    }

    public void setUtjeans(Jeans utjeans) {
        this.utjeans = utjeans;
    }

    public void setUttenis(Tenis uttenis) {
        this.uttenis = uttenis;
    }
    


      
    
          
    
    
}
