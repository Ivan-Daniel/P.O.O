/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Individuos;

import javax.swing.JOptionPane;

/**
 *
 * @author USUARIO
 */
public class Usuario extends Persona{
    private String clave;

    public Usuario( String nombre, long Id,String clave) {
        super(nombre, Id);
        this.clave = clave;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

   
    

    public void validar(String elnombreus, int Laclaveus ){
        if (this.nombre.equals(elnombreus)){
        if (this.clave.equals(Laclaveus)){
         JOptionPane.showMessageDialog(null, "Bienvenido al Sistema");
      }
      else {
        JOptionPane.showMessageDialog(null,"La contraseña es incorrecta");
      } 
    }
   else {
     JOptionPane.showMessageDialog(null,"El usuario es invalido");
   }
    
}

    @Override
    public void validacion(String nombreus, int claveus) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
