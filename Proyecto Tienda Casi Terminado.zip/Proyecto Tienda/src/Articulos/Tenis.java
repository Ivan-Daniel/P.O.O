/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Articulos;


public class Tenis {
    private String marca;
    private double talla;
    private double precio;

    public Tenis(String marca, double talla, double precio) {
        this.marca = marca;
        this.talla = talla;
        this.precio = precio;
    }

    public String getMarca() {
        return marca;
    }

    public double getTalla() {
        return talla;
    }

    public double getPrecio() {
        return precio;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setTalla(double talla) {
        this.talla = talla;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
}
