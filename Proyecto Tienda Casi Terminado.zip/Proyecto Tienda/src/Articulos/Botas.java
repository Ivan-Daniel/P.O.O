
package Articulos;


public class Botas {
    private String marca;
    private double talla;
    private double precio;

    public Botas(String marca, double talla, double precio) {
        this.marca = marca;
        this.talla = talla;
        this.precio = precio;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setTalla(double talla) {
        this.talla = talla;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getMarca() {
        return marca;
    }

    public double getTalla() {
        return talla;
    }

    public double getPrecio() {
        return precio;
    }
    
    
}
