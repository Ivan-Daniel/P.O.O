/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyecto.tienda;

import Articulos.*;
import Individuos.*;
import java.util.*;
import java.util.Map.*;
import javax.swing.*;
public class Main {
    //Escaner para las variables de tipo String
    public static Scanner LecStr= new Scanner (System.in);
    //Escaner para las variables de tipo Int
    public static Scanner Lecint= new Scanner (System.in);
    public static Scanner Leclong= new Scanner (System.in);
    //Lista de Objetos para Usuario
      List<Integer> s=new ArrayList<Integer>();
      //Lista de Objetos para Tienda
      List<Integer> sc=new ArrayList<Integer>();


    public static void main(String[] args) {
        //Se crean objeto Uusario ya establecido
        Usuario objetoUsuario= new Usuario ("ivan",1117485452,"perro");
        //Se crean objeto Uusario ya establecido
        Usuario objetoUsuario2= new Usuario ("Santiago",1004791188,"HPT");
        //Se crea una lista tipo HashMap el cual almacena los objetos y los guarda con una clave
        Map<String,Usuario> lista= new HashMap<String,Usuario>();
        //Se añade el objetoUsuario junto con su clave
        lista.put(objetoUsuario.getClave(), objetoUsuario);
        //Se añade el objetoUsuario2 junto con su clave
        lista.put(objetoUsuario2.getClave(), objetoUsuario2);
        
        Tenis cupo=new Tenis("Nike",10,75000);
        Jeans cupo2= new Jeans("Americanino",36,45000);
        Camisas cupo3= new Camisas("Arturo calle","L",35000);
        Botas cupo4= new Botas ("Columbian",36,80000);
        Tienda x=new Tienda(cupo4,cupo3,cupo2,cupo,"Juan",315125);
        
        
     //Se crea un contador
        
        int caption = 1;
        JOptionPane.showMessageDialog(null,"Bienvenido al Sistema");
       
        do {
            int seleccion=Integer.parseInt(JOptionPane.showInputDialog("Ya estas registrado? "+"\n"+"1) NO 2) Si"));
            //Se crea un switch para poder diferenciar las 2 personas
        switch (seleccion){
            case 1:{
            
            String name=JOptionPane.showInputDialog("ingrese su nombre");
            long id= Long.parseLong(JOptionPane.showInputDialog("Ingrese su ID"));
            Cliente objetoCliente= new Cliente(name,id);
            x.Carta();
            String marc_camisa=JOptionPane.showInputDialog("Ingrese la marca de camisa que se va a llevar");
            String talla_camisa=JOptionPane.showInputDialog("Ingrese la talla de la camisa que se va a llevar");
            double precio_camisas=Double.parseDouble(JOptionPane.showInputDialog("Ingrese el precio de la camisa a llevar")); 
            int cant_camisas= Integer.parseInt(JOptionPane.showInputDialog("Cuantas Camisas te vas a llevar?"));
            //Objeto Camisas
            Camisas objetoCamisas= new Camisas(marc_camisa, talla_camisa, precio_camisas);
              //----------------------------------
            String marc_jeans=JOptionPane.showInputDialog("Ingrese la marca de jean que se va a llevar");
            double talla_jeans=Double.parseDouble(JOptionPane.showInputDialog("Ingrese la talla del jean a llevar")); 
            double precio_jeans=Double.parseDouble(JOptionPane.showInputDialog("Ingrese el precio del jean a llevar")); 
            int cant_jeans=Integer.parseInt(JOptionPane.showInputDialog("Cuantos Jeans te vas a llevar?"));
            //Obejto Jeans
            Jeans objetoJeans=new Jeans(marc_jeans, talla_jeans, precio_jeans);
            //----------------------------------
            String marc_tenis=JOptionPane.showInputDialog("Ingrese la marca de tenis que se va a llevar");
            double talla_tenis=Double.parseDouble(JOptionPane.showInputDialog("Ingrese la talla de tenis que se va a llevar")); 
            double precio_tenis=Double.parseDouble(JOptionPane.showInputDialog("Ingrese el precio de lso tenis que se va a llevar")); 
            int cant_tenis=Integer.parseInt(JOptionPane.showInputDialog("Cuantos tenis te vas a llevar?"));
            //Obejto Tenis
            Tenis objetoTenis=new Tenis(marc_tenis, talla_tenis, precio_tenis);
            //----------------------------------
            String marc_botas=JOptionPane.showInputDialog("Ingrese la marca de Botas que se va a llevar");
            double talla_botas=Double.parseDouble(JOptionPane.showInputDialog("Ingrese la talla de las Botas a llevar")); 
            double precio_botas=Double.parseDouble(JOptionPane.showInputDialog("Ingrese el precio de las Botas a llevar")); 
            int cant_botas=Integer.parseInt(JOptionPane.showInputDialog("Cuantos Botas te vas a llevar?"));
            //Objeto Botas
            Botas objetoBotas=new Botas(marc_botas, talla_botas, precio_botas);
            //----------------------------------
            Tienda y =new Tienda(cant_botas, cant_camisas, cant_tenis, cant_jeans, objetoBotas, objetoCamisas, objetoJeans, objetoTenis, name, id);
            y.factura_botas();
            y.factura_camisa();
            y.factura_jeans();
            y.factura_tenis();
             caption=Integer.parseInt(JOptionPane.showInputDialog("Quieres volver a hacer otra compra? "+"\n"+"1) Para si 2( para no"));
            
            }
            case 2:{
        String name=JOptionPane.showInputDialog("ingrese su nombre");
        long id= Long.parseLong(JOptionPane.showInputDialog("Ingrese su ID"));
        String contra=JOptionPane.showInputDialog("ingrese su contrseña");
        if (objetoUsuario.validacion(name, contra)==false){
            System.exit(0);
        }
        
        /*
        for (Entry<String, Usuario> e: lista.entrySet()) {
            System.out.println(e);
            }*/
        
        x.Carta();
        String marc_camisa=JOptionPane.showInputDialog("Ingrese la marca de camisa que se va a llevar");
            String talla_camisa=JOptionPane.showInputDialog("Ingrese la talla de la camisa que se va a llevar");
            double precio_camisas=Double.parseDouble(JOptionPane.showInputDialog("Ingrese el precio de la camisa a llevar")); 
            int cant_camisas= Integer.parseInt(JOptionPane.showInputDialog("Cuantas Camisas te vas a llevar?"));
            //Objeto Camisas
            Camisas objetoCamisas= new Camisas(marc_camisa, talla_camisa, precio_camisas);
              //----------------------------------
            String marc_jeans=JOptionPane.showInputDialog("Ingrese la marca de jean que se va a llevar");
            double talla_jeans=Double.parseDouble(JOptionPane.showInputDialog("Ingrese la talla del jean a llevar")); 
            double precio_jeans=Double.parseDouble(JOptionPane.showInputDialog("Ingrese el precio del jean a llevar")); 
            int cant_jeans=Integer.parseInt(JOptionPane.showInputDialog("Cuantos Jeans te vas a llevar?"));
            //Obejto Jeans
            Jeans objetoJeans=new Jeans(marc_jeans, talla_jeans, precio_jeans);
            //----------------------------------
            String marc_tenis=JOptionPane.showInputDialog("Ingrese la marca de tenis que se va a llevar");
            double talla_tenis=Double.parseDouble(JOptionPane.showInputDialog("Ingrese la talla de tenis que se va a llevar")); 
            double precio_tenis=Double.parseDouble(JOptionPane.showInputDialog("Ingrese el precio de lso tenis que se va a llevar")); 
            int cant_tenis=Integer.parseInt(JOptionPane.showInputDialog("Cuantos tenis te vas a llevar?"));
            //Obejto Tenis
            Tenis objetoTenis=new Tenis(marc_tenis, talla_tenis, precio_tenis);
            //----------------------------------
            String marc_botas=JOptionPane.showInputDialog("Ingrese la marca de Botas que se va a llevar");
            double talla_botas=Double.parseDouble(JOptionPane.showInputDialog("Ingrese la talla de las Botas a llevar")); 
            double precio_botas=Double.parseDouble(JOptionPane.showInputDialog("Ingrese el precio de las Botas a llevar")); 
            int cant_botas=Integer.parseInt(JOptionPane.showInputDialog("Cuantos Botas te vas a llevar?"));
            //Objeto Botas
            Botas objetoBotas=new Botas(marc_botas, talla_botas, precio_botas);
            //----------------------------------
            Tienda t =new Tienda(cant_botas, cant_camisas, cant_tenis, cant_jeans, objetoBotas, objetoCamisas, objetoJeans, objetoTenis, name, id);
            t.factura_botas();
            t.factura_camisa();
            t.factura_jeans();
            t.factura_tenis();

        
        caption=Integer.parseInt(JOptionPane.showInputDialog("Quieres volver a hacer otra compra? "+"\n"+"1) Para si 2( para no"));
            }
        }
       
        
        } while(caption==1);
    }
    
}
