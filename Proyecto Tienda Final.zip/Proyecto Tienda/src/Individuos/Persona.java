

package Individuos;

import javax.swing.*;
import java.util.*;



/**
 *
 * @author SALA
 */
public abstract class Persona {
    public String nombre;
    public long Id;
    
    public Persona (String nombre, long Id){
        this .Id=Id;
        
        this.nombre=nombre;
        
    }

    public abstract boolean validacion(String nombreus, String claveus);
    
}
