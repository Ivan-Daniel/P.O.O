
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Individuos;

/**
 *
 * @author USUARIO
 */
public class Cliente extends Persona{

    public Cliente(String nombre, long Id) {
        super(nombre, Id);
    }

    @Override
    public boolean validacion(String nombreus, String claveus) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }




}